package com.saadspices.invoices

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Product(val id:String,val name:String,val unit:String,val price:Double)
data class Customer(val id:String,val name:String,val phone:String)
data class Line(val productId:String,val name:String,val unit:String,val qty:Double,val price:Double) {
    val total get() = qty * price
}
data class Invoice(val id:String,val customerId:String,val customerName:String,val date:String,val lines:List<Line>,val paid:Double,val history:List<String> = emptyList()) {
    val total get() = lines.sumOf { it.total }
    val remaining get() = total-paid
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { App(this) } }
}

private fun uid() = System.currentTimeMillis().toString()
private fun money(v:Double) = String.format(Locale.US,"%.2f",v)
private fun dateNow() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(context: Context) {
    val prefs = remember { context.getSharedPreferences("saad_spices_data", Context.MODE_PRIVATE) }
    var products by remember { mutableStateOf(loadProducts(prefs)) }
    var customers by remember { mutableStateOf(loadCustomers(prefs)) }
    var invoices by remember { mutableStateOf(loadInvoices(prefs)) }
    var tab by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    fun saveAll() {
        prefs.edit().putString("products", JSONArray().apply { products.forEach { put(JSONObject().put("id",it.id).put("name",it.name).put("unit",it.unit).put("price",it.price)) } }.toString())
            .putString("customers", JSONArray().apply { customers.forEach { put(JSONObject().put("id",it.id).put("name",it.name).put("phone",it.phone)) } }.toString())
            .putString("invoices", JSONArray().apply { invoices.forEach { inv -> put(JSONObject().put("id",inv.id).put("customerId",inv.customerId).put("customerName",inv.customerName).put("date",inv.date).put("paid",inv.paid).put("history",JSONArray().apply { inv.history.forEach { put(it) } }).put("lines",JSONArray().apply { inv.lines.forEach { put(JSONObject().put("productId",it.productId).put("name",it.name).put("unit",it.unit).put("qty",it.qty).put("price",it.price)) } })) } }.toString()).apply()
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF176B3A), secondary = androidx.compose.ui.graphics.Color(0xFFB78A35))) {
        Scaffold(topBar = { TopAppBar(title = { Text("Spice Data") }, colors = TopAppBarDefaults.topAppBarColors(containerColor=MaterialTheme.colorScheme.primary, titleContentColor=androidx.compose.ui.graphics.Color.White)) },
            bottomBar = { NavigationBar { listOf("الرئيسية","الفواتير","الزبائن","الأصناف","التقارير").forEachIndexed { i,s -> NavigationBarItem(selected=tab==i,onClick={tab=i},icon={ Icon(when(i){0->Icons.Default.Home;1->Icons.Default.ReceiptLong;2->Icons.Default.Store;3->Icons.Default.Inventory2;else->Icons.Default.BarChart},null) },label={Text(s)}) } } }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(12.dp)) {
                when(tab) {
                    0 -> Home(products,customers,invoices,{tab=1},{tab=3})
                    1 -> InvoiceScreen(customers,products,invoices,{ list -> invoices=list; saveAll() },{ message=it })
                    2 -> CustomerScreen(customers,{ customers=it; saveAll() })
                    3 -> ProductScreen(products,{ products=it; saveAll() })
                    4 -> Reports(customers,products,invoices)
                }
                if(message.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(message); TextButton(onClick={message=""}) { Text("إغلاق") } }
            }
        }
    }
}

@Composable fun Home(products:List<Product>,customers:List<Customer>,invoices:List<Invoice>,newInvoice:()->Unit,productsPage:()->Unit) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("مرحباً بك", style=MaterialTheme.typography.headlineMedium)
        Text("إدارة فواتير ومبيعات البهارات", style=MaterialTheme.typography.bodyLarge)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            StatCard("الزبائن",customers.size.toString(),Modifier.weight(1f))
            StatCard("الأصناف",products.size.toString(),Modifier.weight(1f))
            StatCard("الفواتير",invoices.size.toString(),Modifier.weight(1f))
        }
        Button(onClick=newInvoice, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Add,null); Spacer(Modifier.width(8.dp)); Text("إنشاء فاتورة جديدة") }
        OutlinedButton(onClick=productsPage, modifier=Modifier.fillMaxWidth()) { Text("إدارة الأصناف والأسعار") }
        val total=invoices.sumOf { it.total }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("إجمالي المبيعات المسجلة"); Text("$ "+money(total),style=MaterialTheme.typography.headlineMedium); Text("المبالغ المتبقية: $ "+money(invoices.sumOf{it.remaining})) } }
        Text("آخر الفواتير",style=MaterialTheme.typography.titleLarge)
        invoices.takeLast(5).reversed().forEach { Text("${it.date} · ${it.customerName} · $ ${money(it.total)}") }
    }
}
@Composable fun StatCard(label:String,value:String,modifier:Modifier=Modifier) { Card(modifier) { Column(Modifier.padding(12.dp)) { Text(label); Text(value,style=MaterialTheme.typography.headlineMedium) } } }

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun ProductScreen(products:List<Product>,onChange:(List<Product>)->Unit) {
    var name by remember { mutableStateOf("") }; var price by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Product?>(null) }; var editPrice by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Text("الأصناف",style=MaterialTheme.typography.titleLarge)
        OutlinedTextField(name,{name=it},label={Text("اسم الصنف")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(price,{price=it},label={Text("سعر العبوة ($)")},modifier=Modifier.fillMaxWidth())
        Button(onClick={ val p=price.toDoubleOrNull(); if(name.isNotBlank()&&p!=null&&p>=0){onChange(products+Product(uid(),name.trim(),"عبوة",p));name="";price=""} },modifier=Modifier.fillMaxWidth()) { Text("إضافة صنف") }
        Text("اضغط على أي صنف لتعديل سعره. جميع الأصناف بوحدة العبوة.",style=MaterialTheme.typography.bodySmall)
        HorizontalDivider(Modifier.padding(vertical=8.dp))
        LazyColumn { items(products,key={it.id}) { p -> ListItem(headlineContent={Text(p.name)},trailingContent={Row { TextButton(onClick={editing=p;editPrice=p.price.toString()}){Text("تعديل السعر")}; IconButton(onClick={onChange(products.filterNot{it.id==p.id})}){Icon(Icons.Default.Delete,"حذف")} }}) } }
    }
    if(editing!=null) AlertDialog(onDismissRequest={editing=null},title={Text("تعديل سعر ${editing!!.name}")},text={OutlinedTextField(editPrice,{editPrice=it},label={Text("سعر العبوة ($)")})},confirmButton={TextButton(onClick={val v=editPrice.toDoubleOrNull();val e=editing;if(v!=null&&v>=0&&e!=null)onChange(products.map{if(it.id==e.id)it.copy(price=v) else it});editing=null}){Text("حفظ")}},dismissButton={TextButton(onClick={editing=null}){Text("إلغاء")}})
}
@Composable fun CustomerScreen(customers:List<Customer>,onChange:(List<Customer>)->Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Text("الزبائن",style=MaterialTheme.typography.titleLarge)
        OutlinedTextField(name,{name=it},label={Text("اسم الزبون / المتجر")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(phone,{phone=it},label={Text("رقم الهاتف (اختياري)")},modifier=Modifier.fillMaxWidth())
        Button(onClick={if(name.isNotBlank()){onChange(customers+Customer(uid(),name.trim(),phone.trim()));name="";phone=""}},modifier=Modifier.fillMaxWidth()){Text("إضافة زبون")}
        HorizontalDivider(Modifier.padding(vertical=8.dp))
        LazyColumn { items(customers,key={it.id}) { c -> ListItem(headlineContent={Text(c.name)},supportingContent={Text(c.phone.ifBlank{"لا يوجد رقم هاتف"})},trailingContent={IconButton(onClick={onChange(customers.filterNot{it.id==c.id})}){Icon(Icons.Default.Delete,"حذف")}}) } }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun InvoiceScreen(customers:List<Customer>,products:List<Product>,invoices:List<Invoice>,onChange:(List<Invoice>)->Unit,notify:(String)->Unit) {
    var customerId by remember { mutableStateOf("") }; var paid by remember { mutableStateOf("0") }
    var lines by remember { mutableStateOf(listOf<Line>()) }
    var custExpanded by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Invoice?>(null) }
    var editCustomer by remember { mutableStateOf("") }; var editDate by remember { mutableStateOf("") }; var editPaid by remember { mutableStateOf("") }
    var editLines by remember { mutableStateOf(listOf<Line>()) }; var editHistory by remember { mutableStateOf(listOf<String>()) }
    Column(Modifier.fillMaxSize()) {
        Text("فاتورة جديدة",style=MaterialTheme.typography.titleLarge)
        if(customers.isEmpty()||products.isEmpty()) Text("أضف زبوناً وصنفاً أولاً من القائمتين.")
        ExposedDropdownMenuBox(expanded=custExpanded,onExpandedChange={custExpanded=it}) {
            OutlinedTextField(customers.firstOrNull{it.id==customerId}?.name.orEmpty(),{},readOnly=true,label={Text("اختيار الزبون")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(custExpanded)},modifier=Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded=custExpanded,onDismissRequest={custExpanded=false}) { customers.forEach { c -> DropdownMenuItem(text={Text(c.name)},onClick={customerId=c.id;custExpanded=false}) } }
        }
        Text("اضغط على الصنف لإضافة 4 عبوات في كل مرة",style=MaterialTheme.typography.bodySmall)
        Column(Modifier.heightIn(max=150.dp).verticalScroll(rememberScrollState())) {
            products.forEach { p -> OutlinedButton(onClick={val old=lines.firstOrNull{it.productId==p.id};lines=if(old==null) lines+Line(p.id,p.name,"عبوة",4.0,p.price) else lines.map{if(it.productId==p.id)it.copy(qty=it.qty+4)else it};},modifier=Modifier.fillMaxWidth()) { Text(p.name) } }
        }
        OutlinedTextField(paid,{paid=it},label={Text("المبلغ المدفوع ($)")},modifier=Modifier.fillMaxWidth())
        HorizontalDivider(Modifier.padding(vertical=6.dp))
        LazyColumn(Modifier.weight(1f)) { items(lines,key={it.productId}) { l -> ListItem(headlineContent={Text(l.name)},supportingContent={Text("${l.qty} عبوة × $ ${money(l.price)}")},trailingContent={Row(verticalAlignment=Alignment.CenterVertically){Text("$ ${money(l.total)}");IconButton(onClick={lines=lines.filterNot{it.productId==l.productId}}){Icon(Icons.Default.Delete,"حذف")}}}) } }
        val total=lines.sumOf{it.total}
        Text("الإجمالي: $ ${money(total)}",style=MaterialTheme.typography.titleLarge)
        Button(onClick={val c=customers.firstOrNull{it.id==customerId};val payment=paid.toDoubleOrNull();if(c!=null&&lines.isNotEmpty()&&payment!=null&&payment>=0){onChange(invoices+Invoice(uid(),c.id,c.name,dateNow(),lines,payment));lines= emptyList();paid="0";notify("تم حفظ الفاتورة")}else notify("اختر زبوناً وأضف أصنافاً وتأكد من المبلغ المدفوع.")},modifier=Modifier.fillMaxWidth()){Text("حفظ الفاتورة")}
        HorizontalDivider(Modifier.padding(vertical=6.dp))
        Text("الفواتير المحفوظة (${invoices.size})",style=MaterialTheme.typography.titleMedium)
        LazyColumn(Modifier.weight(1f)) { items(invoices.reversed(),key={it.id}) { inv -> Card(Modifier.fillMaxWidth().padding(vertical=3.dp)) { Row(Modifier.fillMaxWidth().padding(8.dp),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)){Text(inv.customerName,style=MaterialTheme.typography.titleMedium);Text("${inv.date} · الإجمالي $ ${money(inv.total)} · المتبقي $ ${money(inv.remaining)}",style=MaterialTheme.typography.bodySmall)};TextButton(onClick={editing=inv;editCustomer=inv.customerName;editDate=inv.date;editPaid=inv.paid.toString();editLines=inv.lines;editHistory=inv.history}){Text("تعديل")}} } } }
    }
    if(editing!=null) AlertDialog(onDismissRequest={editing=null},title={Text("تعديل الفاتورة")},text={Column(Modifier.heightIn(max=520.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){
        OutlinedTextField(editCustomer,{editCustomer=it},label={Text("اسم الزبون")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(editDate,{editDate=it},label={Text("التاريخ YYYY-MM-DD")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(editPaid,{editPaid=it},label={Text("المبلغ المدفوع ($)")},modifier=Modifier.fillMaxWidth())
        Text("الأصناف والكميات والأسعار")
        editLines.forEachIndexed { i,l -> Card { Column(Modifier.padding(8.dp)){Text(l.name);Row { OutlinedTextField(l.qty.toString(),{v->val n=v.toDoubleOrNull();if(n!=null&&n>0)editLines=editLines.toMutableList().also{it[i]=l.copy(qty=n)}},label={Text("الكمية")},modifier=Modifier.weight(1f));Spacer(Modifier.width(6.dp));OutlinedTextField(l.price.toString(),{v->val n=v.toDoubleOrNull();if(n!=null&&n>=0)editLines=editLines.toMutableList().also{it[i]=l.copy(price=n)}},label={Text("سعر العبوة")},modifier=Modifier.weight(1f))};TextButton(onClick={editLines=editLines.filterIndexed{idx,_->idx!=i}}){Text("حذف الصنف")}} } }
        Text("الإجمالي الجديد: $ ${money(editLines.sumOf{it.total})}")
        if(editHistory.isNotEmpty()){Text("سجل التعديلات",style=MaterialTheme.typography.titleSmall);editHistory.takeLast(5).forEach{Text(it,style=MaterialTheme.typography.bodySmall)}}
    }},confirmButton={TextButton(onClick={val old=editing;val payment=editPaid.toDoubleOrNull();if(old!=null&&editCustomer.isNotBlank()&&editDate.isNotBlank()&&payment!=null&&payment>=0&&editLines.isNotEmpty()){val entry="${dateNow()}: تعديل الفاتورة؛ الإجمالي السابق ${money(old.total)}، الجديد ${money(editLines.sumOf{it.total})}، المدفوع ${money(old.paid)} → ${money(payment)}";val updated=old.copy(customerName=editCustomer.trim(),date=editDate.trim(),lines=editLines,paid=payment,history=old.history+entry);onChange(invoices.map{if(it.id==old.id)updated else it});notify("تم تحديث الفاتورة والتقارير وسجل التعديلات");editing=null}else notify("تحقق من اسم الزبون والتاريخ والمبلغ والأصناف.")}){Text("حفظ التعديلات")}},dismissButton={TextButton(onClick={editing=null}){Text("إلغاء")}})
}
@Composable fun Reports(customers:List<Customer>,products:List<Product>,invoices:List<Invoice>) {
    val total=invoices.sumOf{it.total}; val qtyByProduct=invoices.flatMap{it.lines}.groupBy{it.productId}.mapValues{e->e.value.sumOf{it.qty}}
    val customerSpend=invoices.groupBy{it.customerId}.mapValues{e->e.value.sumOf{it.total}}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("تقارير المبيعات",style=MaterialTheme.typography.headlineSmall)
        StatCard("إجمالي المبيعات","$ "+money(total),Modifier.fillMaxWidth())
        StatCard("المبالغ المستلمة","$ "+money(invoices.sumOf{it.paid}),Modifier.fillMaxWidth())
        StatCard("المبالغ المتبقية","$ "+money(invoices.sumOf{it.remaining}),Modifier.fillMaxWidth())
        Text("الأصناف الأكثر طلباً",style=MaterialTheme.typography.titleLarge)
        qtyByProduct.entries.sortedByDescending{it.value}.forEach { e -> Text("${products.firstOrNull{p->p.id==e.key}?.name ?: "صنف محذوف"}: ${e.value}") }
        Text("مشتريات كل زبون",style=MaterialTheme.typography.titleLarge)
        customerSpend.entries.sortedByDescending{it.value}.forEach { e -> Text("${customers.firstOrNull{it.id==e.key}?.name ?: "زبون"}: $ ${money(e.value)}") }
        Text("تفضيلات الزبون تُستخرج من أصنافه وكمياته المسجلة في الفواتير.",style=MaterialTheme.typography.bodyMedium)
    }
}
private fun Int?.orZero() = this ?: 0
private fun loadProducts(p:android.content.SharedPreferences):List<Product> = try { val a=JSONArray(p.getString("products","[]")); (0 until a.length()).map{val o=a.getJSONObject(it);Product(o.getString("id"),o.getString("name"),o.getString("unit"),o.getDouble("price"))} }catch(_:Exception){emptyList()}
private fun loadCustomers(p:android.content.SharedPreferences):List<Customer> = try { val a=JSONArray(p.getString("customers","[]")); (0 until a.length()).map{val o=a.getJSONObject(it);Customer(o.getString("id"),o.getString("name"),o.optString("phone",""))} }catch(_:Exception){emptyList()}
private fun loadInvoices(p:android.content.SharedPreferences):List<Invoice> = try { val a=JSONArray(p.getString("invoices","[]")); (0 until a.length()).map{val o=a.getJSONObject(it);val ls=o.getJSONArray("lines");Invoice(o.getString("id"),o.getString("customerId"),o.getString("customerName"),o.getString("date"),(0 until ls.length()).map{val l=ls.getJSONObject(it);Line(l.getString("productId"),l.getString("name"),l.getString("unit"),l.getDouble("qty"),l.getDouble("price"))},o.getDouble("paid"),(0 until o.optJSONArray("history")?.length().orZero()).mapNotNull{idx->o.optJSONArray("history")?.optString(idx)})} }catch(_:Exception){emptyList()}
